from flask import Flask, request, render_template
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor

app = Flask(__name__)

# Sample Data (Replace this with your actual dataset)
data = pd.DataFrame({
    'distance': [10, 50, 200, 150, 75],
    'urgency': ['Standard', 'Expedited', 'Same-Day', 'Standard', 'Expedited'],
    'cargo_type': ['Fragile', 'Perishable', 'Heavy', 'Fragile', 'Heavy'],
    'market_conditions': [1.2, 1.5, 1.8, 1.1, 1.3],
    'price': [100, 200, 500, 150, 250]
})

# Define features and target
features = ['distance', 'urgency', 'cargo_type', 'market_conditions']
target = 'price'

X = data[features]
y = data[target]

# Preprocessing for numerical and categorical features
numeric_features = ['distance', 'market_conditions']
categorical_features = ['urgency', 'cargo_type']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(), categorical_features)
    ])

# Create and train the model
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', RandomForestRegressor())
])

# Train/Test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model.fit(X_train, y_train)

# Save the trained model
with open('model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

# Load the trained model (for prediction)
with open('model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    if request.method == 'POST':
        distance = float(request.form['distance'])
        urgency = request.form['urgency']
        cargo_type = request.form['cargo_type']
        market_conditions = float(request.form['market_conditions'])
        
        # Prepare input data for prediction
        input_data = pd.DataFrame({
            'distance': [distance],
            'urgency': [urgency],
            'cargo_type': [cargo_type],
            'market_conditions': [market_conditions]
        })
        
        # Predict price
        prediction = model.predict(input_data)[0]

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
